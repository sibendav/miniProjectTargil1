package geometries;

import premitives.Point3D;
import premitives.Vector;
/**
 * The class: Triangle representing a Triangle in 3D space
 *  implements Polygon class
 * @author  Simha Ben-David & Tahel Nadav
 */
public class Triangle extends Polygon {


    @Override
    //imlements of getNormal fun
    public Vector getNormal(Point3D p){
        return super.getNormal(p);
    }

    //ctr with 3 points
    public Triangle(Point3D _p1, Point3D _p2, Point3D _p3) {
        super(_p1, _p2, _p3);

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        return super.equals(o);
    }








}
