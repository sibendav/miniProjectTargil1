package geometries;

import premitives.Point3D;
import premitives.Vector;
import premitives.Point3D;
import premitives.Vector;
/**
 * The class: Sphere representing a Sphere in the space
 * Fields: center point
 *  implements RadialGeometry abstract class
 * @author  Simha Ben-David & Tahel Nadav
 */
public class Sphere extends RadialGeometry {

    public Point3D get_center() {
        return _center;
    }

    private Point3D _center;

    //ctr with point and radius
    public Sphere(Point3D center,double R) {
        super(R);
        _center=center;
    }
    //copy ctr
    public Sphere(Sphere j) {
        super(j.get_radius());
        _center=j.get_center();
    }

    @Override
    //implements the getNurmal func
    public Vector getNormal(Point3D p) {

        Vector v = p.subtract(_center);
        return v;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (!(obj instanceof Sphere)) return false;
        Sphere oth = (Sphere)obj;
        return _center.equals(oth._center);
    }

    @Override
    public String toString() {
        return "Sphere{" +
                "_center=" + _center +
                '}';
    }



}
