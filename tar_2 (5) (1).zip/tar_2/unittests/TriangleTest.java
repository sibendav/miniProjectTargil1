import geometries.Triangle;
import org.junit.Test;
import premitives.Point3D;
import premitives.Vector;

import static org.junit.Assert.*;
/**
 * The Test Class: TriangleTest
 * @author  Simha Ben-David & Tahel Nadav
 */
public class TriangleTest {

    @Test
    //testing the getnormal function
    public void getNormal() {
        Point3D p1=new Point3D(0,1,0);
        Point3D p2=new Point3D(1,1,1);
        Point3D p3=new Point3D(2,0,2);
        Triangle t=new Triangle(p1,p2,p3);
        Vector v=new Vector(1,0,-1);
        v.normalize();
      // System.out.println(""+v.toString());
        if(t.getNormal(p3).equals(v)==true)
            assertTrue(true);
        else fail("ERROR"+t.getNormal(p3));

    }
}