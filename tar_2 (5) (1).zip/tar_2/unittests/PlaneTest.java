import geometries.Plane;
import org.junit.Test;
import premitives.Point3D;
import premitives.Vector;

import static org.junit.Assert.*;
/**
 * The Test Class: PlaneTest
 * @author  Simha Ben-David & Tahel Nadav
 */
public class PlaneTest {

    @Test
    //testing the getnormal function
    public void getNormal() {
        Point3D point=new Point3D(2,2,3);
        Vector V=new Vector(1,2,3);
        Plane p= new Plane (point,V);

        if(p.getNormal(point).equals(V))
            assertTrue(true);
        else
            fail("ERROR "+p.getNormal(point));
    }
}