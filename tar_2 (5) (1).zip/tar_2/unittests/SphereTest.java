import geometries.Sphere;
import org.junit.Test;
import premitives.Point3D;
import premitives.Vector;

import static org.junit.Assert.*;
/**
 * The Test Class: SphereTest
 * @author  Simha Ben-David & Tahel Nadav
 */
public class SphereTest {

    @Test
    //testing the getnormal function
    public void getNormal() {
        Point3D p=new Point3D(0,0,0);
        Sphere S= new Sphere(p,1.0);
        Vector v=new Vector(1,0,0);
        Point3D p1=new Point3D(1,0,0);
        if(S.getNormal(p1).equals(v)==true)
            assertTrue(true);
        else fail("ERROR"+S.getNormal(p1));
     }
}